from setuptools import setup

setup(name='sample_packaging',
      version='1.0',
      description='Sample packaging',
      url='https://github.com/kartikiyyer/sample-packaging.git',
      author='Kartik',
      author_email='sample@packaging.com',
      license='MIT',
      packages=['sample_packaging'],
      safe_zip=False)
